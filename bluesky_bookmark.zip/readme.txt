﻿=== Bluesky Bookmark and Share ===
Contributors: bluesky studio
Donate link: http://bs.bluesky.cn/
Tags: bookmark, share, Chinese
Requires at least: 2.5
Tested up to: 2.8
Stable tag: trunk


Bluesky Bookmark and Share WordPress plugin allows users to bookmark or share your post to many social bookmarking sites, mostly in Chinese.

== Description ==

集合式主流中文收藏分享按钮。在每篇文章后头添加一个按钮，方便用户将文章加入到他们的网络收藏夹中。有：本地收藏夹、谷歌书签、百度搜藏、雅虎收藏、QQ书签、新浪ViVi、365key、挖客、微软Live、和讯网摘、Mister-Wong、收客、Diglog、央库、就喜欢、乐收、POCO、豆瓣、校内、Delicious、Digg、Facebook、Twitter、Myspace等收藏选择项。

== Installation ==

1. 将“bluesky_bookmark.zip”解压到`/wp-content/plugins/bluesky_bookmark` 目录下。
2. 在管理后台激活插件“Bluesky Bookmark and Share”。
3. 在管理后台到“设置”项的“收藏与分享”选择需要的书签服务和按钮类型。

== Screenshots ==

1. Presentation of Bookmark and Share choice.网络收藏选择显示。


