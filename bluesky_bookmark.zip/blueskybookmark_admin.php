<?php if (realpath(@$_SERVER['SCRIPT_FILENAME']) == realpath(__FILE__)) exit("Access Denied"); ?>

<style type="text/css">
.addList2{ margin:0; padding:0; list-style:none; line-height:20px;}
.addList2 li{ width:186px; height:22px; margin:0 8px 1px 3px; float:left; display:inline;}
.addList2 li a{ margin:0 0 0 2px; padding:0 0 0 20px;}
.addList2 li a.onpadd{ padding:0;}
.addList2 li input{ float:left; margin-right:5px;}
.addList2 li.on{ width:184px; height:20px; background:#ECF4F7; border:#B4D0DA solid 1px;}
.blueskybookmark_code_hide{ display:none;}
</style>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script>
<script type="text/javascript" src="http://bluesky-bookmark.googlecode.com/svn/trunk/bs.js"></script>
<div class="wrap">
<h2>蓝天.收藏与分享</h2>
<form method="post" action="options.php">
	<?php wp_nonce_field('update-options'); ?>
	<input type="hidden" name="blueskybookmark_code" value='<?php echo get_option('blueskybookmark_code'); ?>' />
	<div class="blueskybookmark_code_hide"></div>
	<table class="form-table">
	<tr valign="top">
	<th scope="row">选择按钮</th>
	<td><ul class="btnList addList2"></ul>
	<input name="selectall" type="checkbox" value="" checked="checked" />全选
	<br style="clear:both;" />
	</td>
	</tr>
	<tr valign="top">
	<th scope="row">选择样式</th>
	<td>
	<ul class="addList2">
		<li><input name="style" type="radio" value="bookmark.gif" checked="checked" /><img src="<?php echo $blueskybookmark_plugin_url ?>/bookmark.gif" alt="" /></li>
		<li><input name="style" type="radio" value="bookmark_lg.gif" /><img src="<?php echo $blueskybookmark_plugin_url ?>/bookmark_lg.gif" alt="" /></li>
		<li><input name="style" type="radio" value="share_lg.gif" /><img src="<?php echo $blueskybookmark_plugin_url ?>/share_lg.gif" alt="" /></li>
		<li><input name="style" type="radio" value="bookmark_sm.gif" /><img src="<?php echo $blueskybookmark_plugin_url ?>/bookmark_sm.gif" alt="" /></li>
		<li><input name="style" type="radio" value="share_sm.gif" /><img src="<?php echo $blueskybookmark_plugin_url ?>/share_sm.gif" alt="" /></li>
	</ul>
	<div style="clear:both;">
	<input name="style" class="radioTxt" type="radio" value="" />文字<input name="styleTxt" value="" type="text" size="8" maxlength="20" />
	</div>
	</td>
	</tr>
	<tr valign="top">
	<th scope="row">事件绑定</th>
	<td>
	<input name="event" type="radio" value="mouseover" />mouseover（放上鼠标即显示）&nbsp; &nbsp; 
	<input name="event" type="radio" value="click" checked="checked" />click（鼠标点击显示）
	</td>
	</tr>
	<tr valign="top">
	<th scope="row">显示位置</th>
	<td>
	<input type="checkbox" name="blueskybookmark_show[]" value="home" <?php blueskybookmark_checked_place("home", true); ?> />在首页显示 &nbsp; <input type="checkbox" name="blueskybookmark_show[]" value="page" <?php blueskybookmark_checked_place("page", true); ?> />在Page页显示 &nbsp; <input type="checkbox" name="blueskybookmark_show[]" value="category" <?php blueskybookmark_checked_place("category", true); ?> />在分类页显示 <br /> <input type="checkbox" name="blueskybookmark_show[]" value="archive" <?php blueskybookmark_checked_place("archive", true); ?> />在存档页显示 &nbsp;
	<input type="checkbox" name="blueskybookmark_show[]" value="search" <?php blueskybookmark_checked_place("search", true); ?> />在搜索页显示 
	</td>
	</tr>
	<tr valign="top">
	<th scope="row">预览</th>
	<td>
	<div class="addthisPreview"></div>
	</td>
	</tr>
	</table>
	<input type="hidden" name="action" value="update" />
	<input type="hidden" name="page_options" value="blueskybookmark_code,blueskybookmark_show" />
	<p class="submit">
	<input type="submit" name="Submit" value="<?php _e('Save Changes') ?>" />
	</p>
</form>
</div>
<script type="text/javascript">
$(function(){
	$(".blueskybookmark_code_hide").html($("input[name='blueskybookmark_code']").val());
	var atObj = $(".blueskybookmark_code_hide .bs_bluesky_cn a");
	
	var btnsHtml='';
	for(var key in $$addthis.favs){
		if ($$addthis.favs[key].id>=0) {
			btnsHtml+='<li><input name="item" type="checkbox" value="'+ $$addthis.favs[key].id +'"';
			if (!atObj.attr("i") || (('|'+atObj.attr("i")+'|').indexOf('|'+$$addthis.favs[key].id+'|')>=0)) {
				btnsHtml+=' checked="checked"';
			}
			btnsHtml+=' /><a class="add_'+ $$addthis.favs[key].id +'" item="'+ $$addthis.favs[key].id +'" href="#">'+ $$addthis.favs[key].name +'</a></li>'
		}
	}
	$(".btnList").html(btnsHtml);
	
	if (atObj.find("img").length>0){
		$("input[name='style']").each(function(){
			if (atObj.find("img").attr("src").indexOf($(this).val())>0) {
				$(this).attr("checked","checked");
			} else {
				$(this).removeAttr("checked");
			}
		});
		$("input.radioTxt").removeAttr("checked");
	} else {//属于文字
		$("input[name='style']").removeAttr("checked");
		$("input.radioTxt").attr("checked","checked");
		$("input.radioTxt").val(atObj.html());
		$("input[name='styleTxt']").val(atObj.html());
	}
	
	$("input[name='event']").each(function(){
		if (atObj.attr("e")==$(this).val()) {
			$(this).attr("checked","checked");
		} else if (atObj.attr("e")) {
			$(this).removeAttr("checked");
		}
	});
	
	
	
	$("input[name='selectall']").click(function(){
		if ($(this).attr("checked")) {
			$("input[name='item']").attr("checked","checked");
		} else {
			$("input[name='item']").removeAttr("checked");
		}
	});
	getCode();
	$("input[name='item']").click(getCode);
	$("input[name='style']").click(getCode);
	$("input[name='styleTxt']").change(function(){$("input.radioTxt").val($(this).val()); getCode();});
	$("input[name='selectall']").click(getCode);
	$("input[name='event']").click(getCode);
});

function getCode(){
	var i='';
	if ($("input[name='item']:not(:checked)").length>0) {
		$("input:checked[name='item']").each(function(){ i=="" ? i+=$(this).val().toString() : i+="|"+$(this).val().toString();});
	}
	var img = $("input:checked[name='style']").val();
	if (img.indexOf(".gif")>0) {
		img = "<img src=\"<?php echo $blueskybookmark_plugin_url ?>/"+ img +"\" alt=\"蓝天.收藏与分享\" border=\"0\" align=\"absmiddle\" />";
	}
	var e = $("input:checked[name='event']").val();
	var str = '';
	str += "<span style=\"position:relative;z-index:999\"><span style=\"position:relative;\" class=\"bs_bluesky_cn\"><a href=\"http://bs.bluesky.cn\""+ (i=="" ? "" : " i=\""+ i +"\"") + (e=="click" ? " e=\""+ e +"\"":"") +" title=\"收藏与分享\">"+ img +"</a></span></span>"; 
	$(".addthisPreview").html(str);
	$("input[name='blueskybookmark_code']").val(str);
	$$addthis.rebind();
}


function  HTMLEnCode(str)  
{  
	 var    s    =    "";  
	 if    (str.length    ==    0)    return    "";  
	 s    =    str.replace(/&/g,    "&gt;");  
	 s    =    s.replace(/</g,        "&lt;");  
	 s    =    s.replace(/>/g,        "&gt;");  
	// s    =    s.replace(/ /g,        "&nbsp;");  
	 s    =    s.replace(/\'/g,      "&#39;");  
	 s    =    s.replace(/\"/g,      "&quot;");  
	// s    =    s.replace(/\n/g,      "<br>");  
	 return    s;  
   } 
</script>

