<?php if (realpath(@$_SERVER['SCRIPT_FILENAME']) == realpath(__FILE__)) exit("Access Denied"); 
?>
<?php
/**
* Plugin Name: Bluesky Bookmark and Share
* Plugin URI: http://bs.bluesky.cn
* Description: 集合式主流中文收藏与分享按钮。
* Version: 1.0
* Author: Bluesky Studio
* Author URI: http://bs.bluesky.cn
*/


if ( !defined('WP_CONTENT_URL') ) 
    define( 'WP_CONTENT_URL', get_option('siteurl') . '/wp-content'); 
if ( !defined('WP_CONTENT_DIR') ) 
    define( 'WP_CONTENT_DIR', ABSPATH . 'wp-content' ); 
// Guess the location 
$blueskybookmark_plugin_path = WP_CONTENT_DIR.'/plugins/'.plugin_basename(dirname(__FILE__)); 
$blueskybookmark_plugin_url = WP_CONTENT_URL.'/plugins/'.plugin_basename(dirname(__FILE__)); 

add_option("blueskybookmark_show", array("archive"));
add_option("blueskybookmark_code", "<span style=\"position:relative;z-index:999\"><span style=\"position:relative;\" class=\"bs_bluesky_cn\"><a href=\"http://bs.bluesky.cn\" title=\"收藏&amp;分享\"><img src=\"". $blueskybookmark_plugin_url ."/bookmark.gif\" alt=\"\" border=\"0\" align=\"absmiddle\" /></a></span></span>");

$blueskybookmark_show = get_option("blueskybookmark_show");
$blueskybookmark_code = get_option("blueskybookmark_code");

add_action('admin_menu', 'blueskybookmark_admin_menu'); //增加管理导航
add_filter('the_content', 'blueskybookmark_the_content');
	

function blueskybookmark_the_content($content) {
    global $blueskybookmark_show, $blueskybookmark_code, $blueskybookmark_plugin_url;
	global $post;

    if ((is_home() && !blueskybookmark_checked_place("home")) || 
        (is_page() && !blueskybookmark_checked_place("page")) || 
        (is_category() && !blueskybookmark_checked_place("category")) || 
        (is_archive() && !blueskybookmark_checked_place("archive")) || 
        (is_search() && !blueskybookmark_checked_place("search")) ||
		(is_feed())||(is_tag())) {
        return $content;
    }

    $blueskybookmark_u = get_permalink();
	$blueskybookmark_t = get_the_title();
	$blueskybookmark_d = has_excerpt() ? get_the_excerpt() : "";
	if($blueskybookmark_d==""){
		$blueskybookmark_d=_utrim(strip_tags($post->post_content),100);
	}
	$blueskybookmark_tag = blueskybookmark_get_tags();
	$blueskybookmark_codeHtml = '<script type="text/javascript" src="http://bluesky-bookmark.googlecode.com/svn/trunk/bs.js" charset="UTF-8"></script>'. $blueskybookmark_code;
	$blueskybookmark_codeHtml = preg_replace("/(<span style=\"position:relative;\" class=\"bs_bluesky_cn\"><a)/i", "$1 u=\"".htmlspecialchars($blueskybookmark_u)."\" t=\"".htmlspecialchars($blueskybookmark_t)."\" d=\"".htmlspecialchars(substr($blueskybookmark_d,0,60))."\" tag=\"".htmlspecialchars($blueskybookmark_tag)."\"", $blueskybookmark_codeHtml);

    $content .= "\n" . $blueskybookmark_codeHtml;
    return $content;
}

function blueskybookmark_admin_menu() {
    add_options_page('蓝天.收藏与分享', '收藏与分享', 10, __FILE__, 'blueskybookmark_admin');
	//调用管理页面dd_options_page(page_title, menu_title, access_level/capability, file, [function]);
}

function blueskybookmark_admin() {
    global $blueskybookmark_show, $blueskybookmark_code, $blueskybookmark_plugin_url;

    require_once(dirname(__FILE__) . "/blueskybookmark_admin.php");
}

function blueskybookmark_checked_place($place, $check = false) {
    global $blueskybookmark_show;

    $r = is_array($blueskybookmark_show) && in_array($place, $blueskybookmark_show);
    if ($check && $r) echo " checked=\"checked\"";

    return $r;
}




function blueskybookmark_get_tags() {
    $tags = get_the_tags();
    $arr = array();
    if (is_array($tags)) {
    	foreach ($tags as $tag) {
    		$arr[] = $tag->name;
    	}
    }
    return implode(",", $arr);
}

function _utrim($str,$length) {
	$char = get_bloginfo('charset');
	if (function_exists('iconv_substr')) {
		$l = iconv_strlen($str,$char);
		if ($l<=$length) return $str;
		else {
			return iconv_substr($str,0,$length,$char) . "...";
		}
	} elseif (function_exists('mb_substr')) {
		$l = mb_strlen($str,$char);
		if ($l<=$length) return $str;
		else {
			return mb_substr($str,0,$length,$char) . "...";
		}
	} else {
		$l = strlen($str);
		if ($l<$length) return $str;
		else {
			$r = substr($str,0,$length);
			for ($i=strlen($r)-1; $i>=0; $i-=1){
				$hex .= ' '.ord($r[$i]);
				$ch = ord($r[$i]);
				if (($ch & 128)==0) return substr($r,0,$i)."...";
				if (($ch & 192)==192) return substr($r,0,$i)."...";
			}
			return $r.$hex."...";
		}
	}
}
?>